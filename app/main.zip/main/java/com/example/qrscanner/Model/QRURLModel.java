package com.example.qrscanner.Model;

public class QRURLModel {
    private String url;

    public QRURLModel(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
